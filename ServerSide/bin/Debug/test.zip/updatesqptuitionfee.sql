create procedure [dbo].[SP_SHOW_DETAIL_TUITIONFEE] 
@Ma nchar(10),
@Nienkhoa nchar(9),
@Hocky int
AS
BEGIN
	Select ct.NGAYDONG,ct.SOTIENDONG  from CT_DONGHOCPHI ct
	where ct.MASV = @Ma and ct.NIENKHOA = @Nienkhoa and ct.HOCKY = @Hocky
END

go

create proc [dbo].[SP_PAY_TUITIONFEE]
@Ma nchar(10)
as
begin
select hp.MASV,hp.NIENKHOA, hp.HOCKY,hp.HOCPHI ,
 PADED=isnull((select SUM(CT_DONGHOCPHI.SOTIENDONG) from CT_DONGHOCPHI where CT_DONGHOCPHI.MASV = @Ma and CT_DONGHOCPHI.HOCKY = hp.HOCKY and CT_DONGHOCPHI.NIENKHOA = hp.NIENKHOA),0) 
from HOCPHI as hp
where hp.MASV = @Ma
group by hp.MASV, hp.NIENKHOA,hp.HOCKY,hp.HOCPHI
order by hp.NIENKHOA,hp.HOCKY asc
end
go
create proc [dbo].[SP_PAY_TUITION_MONEY]
@Ma nchar(10),
@Nienkhoa nchar(9),
@Hocky int,
@Ngaydong datetime,
@Sotiendong int
AS
BEGIN
	insert into CT_DONGHOCPHI(MASV,NIENKHOA,HOCKY,NGAYDONG,SOTIENDONG) values(@Ma,@Nienkhoa,@Hocky,@Ngaydong,@Sotiendong)
END